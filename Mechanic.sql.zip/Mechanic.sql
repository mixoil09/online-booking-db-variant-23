-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Май 19 2026 г., 11:13
-- Версия сервера: 8.0.34-26-beget-1-1
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `w95059ji_1`
--

-- --------------------------------------------------------

--
-- Структура таблицы `Mechanic`
--
-- Создание: Май 19 2026 г., 07:13
-- Последнее обновление: Май 19 2026 г., 07:16
--

DROP TABLE IF EXISTS `Mechanic`;
CREATE TABLE `Mechanic` (
  `mechanic_id` int NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `experience_years` decimal(3,1) NOT NULL,
  `priority` int NOT NULL
) ;

--
-- Дамп данных таблицы `Mechanic`
--

INSERT INTO `Mechanic` (`mechanic_id`, `full_name`, `experience_years`, `priority`) VALUES
(1, 'Кузнецов Олег Иванович', '1.5', 5),
(2, 'Смирнова Татьяна Петровна', '3.0', 2),
(3, 'Васильев Андрей Сергеевич', '7.2', 1),
(4, 'Новикова Ирина Владимировна', '0.8', 8);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `Mechanic`
--
ALTER TABLE `Mechanic`
  ADD PRIMARY KEY (`mechanic_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `Mechanic`
--
ALTER TABLE `Mechanic`
  MODIFY `mechanic_id` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
