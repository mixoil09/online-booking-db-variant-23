<?php
require_once 'config.php';
require_once 'src/Exception/RepositoryException.php';
require_once 'src/Database.php';
require_once 'src/Repository/AbstractRepository.php';
require_once 'src/Repository/ClientRepository.php';
require_once 'src/Repository/BikeRepository.php';
require_once 'src/Repository/ServiceRepository.php';
require_once 'src/Repository/MechanicRepository.php';
require_once 'src/Repository/AppointmentRepository.php';
require_once 'src/Repository/PartRepository.php';

use BikeRepair\Database;
use BikeRepair\Repository\ClientRepository;
use BikeRepair\Repository\AppointmentRepository;
use BikeRepair\Repository\PartRepository;
use BikeRepair\Exception\RepositoryException;

header('Content-Type: text/html; charset=utf-8');
echo '<h1>Демонстрация работы DAL для системы велоремонта (вариант 23)</h1>';

try {
    $db = Database::getInstance()->getConnection();
    
    // 1. Клиенты
    echo '<h2>1. Работа с клиентами</h2>';
    $clientRepo = new ClientRepository($db);
    
    $allClients = $clientRepo->findAll([], [], 'full_name');
    echo '<pre>Все клиенты: '; print_r(array_column($allClients, 'full_name')); echo '</pre>';
    
    $client = $clientRepo->findById(1);
    echo '<pre>Клиент с ID=1: '; print_r($client); echo '</pre>';
    
    $newClientId = $clientRepo->create('Тестовый Клиент', '+79998887766', 'test@test.com');
    echo "<p>Создан новый клиент с ID = $newClientId</p>";
    
    // 2. Записи
    echo '<h2>2. Работа с записями</h2>';
    $appointmentRepo = new AppointmentRepository($db);
    
    $completedAppointments = $appointmentRepo->getAllWithDetails('завершено');
    echo '<pre>Завершённые записи: '; print_r(array_column($completedAppointments, 'app_id')); echo '</pre>';
    
    try {
        // Попытка создать сложный ремонт с мастером, у которого опыт < 2 лет
        $newAppId = $appointmentRepo->createAppointment(1, 1, 4, 1, '2026-06-10 14:00:00');
        echo "<p style='color:red'>Ошибка: удалось создать сложный ремонт у мастера с опытом 1.5 года (не должно быть)</p>";
    } catch (RepositoryException $e) {
        echo "<p style='color:green'>Корректно отклонено: " . $e->getMessage() . "</p>";
    }
    
    // Правильное создание записи
    $correctAppId = $appointmentRepo->createAppointment(1, 1, 1, 2, '2026-06-10 15:00:00');
    echo "<p>Создана корректная запись с ID = $correctAppId</p>";
    
    // Обновление статуса
    $appointmentRepo->updateStatus($correctAppId, 'завершено', 30);
    echo "<p>Статус записи $correctAppId обновлён на 'завершено' с временем 30 мин</p>";
    
    // Свободные слоты
    $freeSlots = $appointmentRepo->getFreeSlots(2, '2026-06-10');
    echo '<pre>Свободные слоты мастера 2 на 2026-06-10: '; print_r($freeSlots); echo '</pre>';
    
    // 3. Транзакция (запись + списание деталей)
    echo '<h2>3. Демонстрация транзакции</h2>';
    $partRepo = new PartRepository($db);
    
    try {
        $partsToUse = [1 => 1]; // камера 26" в количестве 1
        $transactionAppId = $appointmentRepo->createAppointmentWithParts(2, 2, 2, 2, '2026-06-11 10:00:00', $partsToUse);
        echo "<p style='color:green'>Транзакция успешна. Создана запись ID = $transactionAppId, детали списаны</p>";
    } catch (RepositoryException $e) {
        echo "<p style='color:red'>Ошибка транзакции: " . $e->getMessage() . "</p>";
    }
    
    // 4. Удаление (демонстрация)
    echo '<h2>4. Удаление</h2>';
    $deleted = $clientRepo->delete($newClientId);
    echo "<p>Тестовый клиент ID=$newClientId " . ($deleted ? 'удалён' : 'не найден') . "</p>";
    
    echo '<hr><h3>Все операции выполнены успешно</h3>';
    
} catch (RepositoryException $e) {
    echo '<h2 style="color:red">Ошибка уровня доступа к данным:</h2>';
    echo '<pre>' . $e->getMessage() . '</pre>';
} catch (Exception $e) {
    echo '<h2 style="color:red">Общая ошибка:</h2>';
    echo '<pre>' . $e->getMessage() . '</pre>';
}