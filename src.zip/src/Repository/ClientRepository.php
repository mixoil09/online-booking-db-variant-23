<?php
namespace BikeRepair\Repository;

use PDO;
use BikeRepair\Exception\RepositoryException;

class ClientRepository extends AbstractRepository
{
    protected string $tableName = 'Client';
    protected string $primaryKey = 'client_id';

    public function __construct(PDO $db)
    {
        parent::__construct($db);
    }

    /**
     * Найти клиента по телефону
     */
    public function findByPhone(string $phone): ?array
    {
        $sql = "SELECT * FROM Client WHERE phone = :phone";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':phone' => $phone]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    /**
     * Найти клиента по email
     */
    public function findByEmail(string $email): ?array
    {
        $sql = "SELECT * FROM Client WHERE email = :email";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':email' => $email]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    /**
     * Создать нового клиента
     */
    public function create(string $fullName, string $phone, ?string $email = null): int
    {
        $sql = "INSERT INTO Client (full_name, phone, email) VALUES (:full_name, :phone, :email)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':full_name' => $fullName,
            ':phone' => $phone,
            ':email' => $email
        ]);
        return (int)$this->db->lastInsertId();
    }

    /**
     * Обновить данные клиента
     */
    public function update(int $clientId, array $data): bool
    {
        $allowedFields = ['full_name', 'phone', 'email'];
        $updates = [];
        $params = [':client_id' => $clientId];
        
        foreach ($data as $field => $value) {
            if (in_array($field, $allowedFields)) {
                $updates[] = "$field = :$field";
                $params[":$field"] = $value;
            }
        }
        
        if (empty($updates)) {
            return false;
        }
        
        $sql = "UPDATE Client SET " . implode(', ', $updates) . " WHERE client_id = :client_id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }

    protected function getAllowedOrderColumns(): array
    {
        return ['client_id', 'full_name', 'phone', 'email'];
    }
}