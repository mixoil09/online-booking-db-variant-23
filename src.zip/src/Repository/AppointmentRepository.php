<?php
namespace BikeRepair\Repository;

use PDO;
use BikeRepair\Exception\RepositoryException;

class AppointmentRepository extends AbstractRepository
{
    protected string $tableName = 'Appointment';
    protected string $primaryKey = 'app_id';

    public function __construct(PDO $db)
    {
        parent::__construct($db);
    }

    /**
     * Получить все записи с JOIN для отображения
     */
    public function getAllWithDetails(string $status = null): array
    {
        $sql = "SELECT a.*, 
                       c.full_name AS client_name,
                       b.frame_type, b.wheel_size,
                       s.service_name, s.type AS service_type,
                       m.full_name AS mechanic_name, m.experience_years
                FROM Appointment a
                JOIN Client c ON a.client_id = c.client_id
                JOIN Bike b ON a.bike_id = b.bike_id
                JOIN Service s ON a.service_id = s.service_id
                JOIN Mechanic m ON a.mechanic_id = m.mechanic_id";
        
        $params = [];
        if ($status !== null) {
            $sql .= " WHERE a.status = :status";
            $params[':status'] = $status;
        }
        
        $sql .= " ORDER BY a.app_datetime DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * Получить записи по дате
     */
    public function findByDate(string $date): array
    {
        $sql = "SELECT * FROM Appointment WHERE DATE(app_datetime) = :date ORDER BY app_datetime";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':date' => $date]);
        return $stmt->fetchAll();
    }

    /**
     * Получить свободные слоты мастера на дату (упрощённо)
     */
    public function getFreeSlots(int $mechanicId, string $date): array
    {
        // Занятые слоты
        $sql = "SELECT TIME(app_datetime) AS slot_time 
                FROM Appointment 
                WHERE mechanic_id = :mechanic_id AND DATE(app_datetime) = :date";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':mechanic_id' => $mechanicId, ':date' => $date]);
        $busySlots = $stmt->fetchAll();
        
        $busyTimes = array_column($busySlots, 'slot_time');
        
        // Доступные слоты (9:00 до 18:00, шаг 1 час)
        $allSlots = [];
        for ($h = 9; $h < 18; $h++) {
            $slot = sprintf('%02d:00:00', $h);
            if (!in_array($slot, $busyTimes)) {
                $allSlots[] = $slot;
            }
        }
        return $allSlots;
    }

    /**
     * Создать новую запись (с проверкой сложного ремонта)
     */
    public function createAppointment(
        int $clientId,
        int $bikeId,
        int $serviceId,
        int $mechanicId,
        string $datetime,
        string $status = 'запланировано'
    ): int {
        // Проверка: сложный ремонт требует опыт мастера > 2 лет
        $checkSql = "SELECT s.type, m.experience_years 
                     FROM Service s, Mechanic m 
                     WHERE s.service_id = :service_id AND m.mechanic_id = :mechanic_id";
        $stmt = $this->db->prepare($checkSql);
        $stmt->execute([':service_id' => $serviceId, ':mechanic_id' => $mechanicId]);
        $check = $stmt->fetch();
        
        if ($check && $check['type'] === 'complex' && $check['experience_years'] <= 2) {
            throw new RepositoryException('Сложный ремонт может выполнять только мастер с опытом более 2 лет');
        }
        
        // Проверка уникальности слота
        $checkSlot = "SELECT 1 FROM Appointment WHERE mechanic_id = :mechanic_id AND app_datetime = :datetime";
        $stmtSlot = $this->db->prepare($checkSlot);
        $stmtSlot->execute([':mechanic_id' => $mechanicId, ':datetime' => $datetime]);
        if ($stmtSlot->fetch()) {
            throw new RepositoryException('Это время уже занято у данного мастера');
        }
        
        $sql = "INSERT INTO Appointment (client_id, bike_id, service_id, mechanic_id, app_datetime, status) 
                VALUES (:client_id, :bike_id, :service_id, :mechanic_id, :datetime, :status)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':client_id' => $clientId,
            ':bike_id' => $bikeId,
            ':service_id' => $serviceId,
            ':mechanic_id' => $mechanicId,
            ':datetime' => $datetime,
            ':status' => $status
        ]);
        return (int)$this->db->lastInsertId();
    }

    /**
     * Обновить статус записи
     */
    public function updateStatus(int $appointmentId, string $status, ?int $actualMinutes = null): bool
    {
        $sql = "UPDATE Appointment SET status = :status";
        $params = [':status' => $status, ':app_id' => $appointmentId];
        
        if ($actualMinutes !== null) {
            $sql .= ", actual_minutes = :actual_minutes";
            $params[':actual_minutes'] = $actualMinutes;
        }
        
        $sql .= " WHERE app_id = :app_id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * Метод с транзакцией: запись + списание деталей (демонстрация)
     */
    public function createAppointmentWithParts(
        int $clientId,
        int $bikeId,
        int $serviceId,
        int $mechanicId,
        string $datetime,
        array $partsUsed
    ): int {
        try {
            $this->db->beginTransaction();
            
            // Создаём запись
            $appointmentId = $this->createAppointment($clientId, $bikeId, $serviceId, $mechanicId, $datetime);
            
            // Списание деталей
            $partRepo = new PartRepository($this->db);
            foreach ($partsUsed as $partId => $quantity) {
                $partRepo->decreaseStock($partId, $quantity);
                $partRepo->addUsedPart($appointmentId, $partId, $quantity);
            }
            
            $this->db->commit();
            return $appointmentId;
        } catch (\Exception $e) {
            $this->db->rollBack();
            throw new RepositoryException('Ошибка при создании записи со списанием деталей: ' . $e->getMessage());
        }
    }

    protected function getAllowedOrderColumns(): array
    {
        return ['app_id', 'app_datetime', 'status', 'actual_minutes'];
    }
}