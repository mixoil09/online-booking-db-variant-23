<?php
namespace BikeRepair\Repository;

use PDO;
use BikeRepair\Exception\RepositoryException;

class PartRepository extends AbstractRepository
{
    protected string $tableName = 'Part';
    protected string $primaryKey = 'part_id';

    public function decreaseStock(int $partId, int $quantity): bool
    {
        $sql = "UPDATE Part SET stock_quantity = stock_quantity - :qty WHERE part_id = :id AND stock_quantity >= :qty";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':qty' => $quantity, ':id' => $partId]);
        
        if ($stmt->rowCount() === 0) {
            throw new RepositoryException("Недостаточно деталей на складе (part_id = $partId)");
        }
        return true;
    }

    public function addUsedPart(int $appointmentId, int $partId, int $quantity): void
    {
        $sql = "INSERT INTO OrderPart (app_id, part_id, quantity_used) VALUES (:app_id, :part_id, :qty)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':app_id' => $appointmentId,
            ':part_id' => $partId,
            ':qty' => $quantity
        ]);
    }

    protected function getAllowedOrderColumns(): array
    {
        return ['part_id', 'part_name', 'stock_quantity', 'price'];
    }
}