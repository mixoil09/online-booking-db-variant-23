<?php
namespace BikeRepair\Repository;

use PDO;
use BikeRepair\Exception\RepositoryException;

abstract class AbstractRepository
{
    protected PDO $db;
    protected string $tableName;
    protected string $primaryKey = 'id';

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    /**
     * Найти все записи с фильтрацией и сортировкой
     */
    public function findAll(array $where = [], array $params = [], string $orderBy = '', int $limit = 0): array
    {
        $sql = "SELECT * FROM {$this->tableName}";
        
        if (!empty($where)) {
            $sql .= " WHERE " . implode(' AND ', $where);
        }
        
        if (!empty($orderBy)) {
            // Белый список столбцов для сортировки (защита от инъекций)
            $allowedColumns = $this->getAllowedOrderColumns();
            $orderColumn = explode(' ', $orderBy)[0];
            if (in_array($orderColumn, $allowedColumns)) {
                $sql .= " ORDER BY $orderBy";
            } else {
                throw new RepositoryException("Недопустимый столбец для сортировки: $orderColumn");
            }
        }
        
        if ($limit > 0) {
            $sql .= " LIMIT " . (int)$limit;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * Найти запись по первичному ключу
     */
    public function findById(int $id): ?array
    {
        $sql = "SELECT * FROM {$this->tableName} WHERE {$this->primaryKey} = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    /**
     * Удалить запись по первичному ключу
     */
    public function delete(int $id): bool
    {
        $sql = "DELETE FROM {$this->tableName} WHERE {$this->primaryKey} = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }

    /**
     * Получить разрешённые столбцы для сортировки (переопределяется в наследниках)
     */
    protected function getAllowedOrderColumns(): array
    {
        return [$this->primaryKey];
    }
}