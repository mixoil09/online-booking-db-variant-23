<?php
// config.example.php - скопируйте в config.php и укажите свои данные
define('DB_HOST', 'localhost');
define('DB_NAME', 'w95059ji_1');
define('DB_USER', 'w95059ji_1');
define('DB_PASS', '*******');
define('DB_CHARSET', 'utf8mb4');