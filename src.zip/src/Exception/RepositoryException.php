<?php
namespace BikeRepair\Exception;

use Exception;

class RepositoryException extends Exception
{
    // Собственное исключение для уровня доступа к данным
}